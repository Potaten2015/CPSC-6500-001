# UML Diagrams

## Packages

![Packages](packages_imu.png)

## Classes

![Classes](classes_imu.png)
